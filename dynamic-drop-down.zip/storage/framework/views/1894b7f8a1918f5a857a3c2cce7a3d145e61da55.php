<?php $__env->startSection('content'); ?>
    <div class="col-md-9">
       <div class="card">
           <div class="card-header">
                <?php if(session('success')): ?>
                    <h5 class="text-success"><?php echo e(session('success')); ?></h5>
                <?php elseif(session('error')): ?>
                    <h5 class="text-danger"><?php echo e(session('errror')); ?></h5>
                <?php else: ?>
                    <h5><?php echo e(_('Add Category')); ?></h5>
                <?php endif; ?>
           </div>
            <div class="row">
                <form action="<?php echo e(route('category.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label class="form-label">Name</label>
                    <input type="text" class="form-control" name="name" placeholder="Enter Category Name" value="">
                </div>
                <div class="form-group">
                    <button class="btn btn-success" type="submit">Save</button>
                </div>
                </form>
            </div>
       </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\dynamic-drop-down\resources\views/category/create.blade.php ENDPATH**/ ?>