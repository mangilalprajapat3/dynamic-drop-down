<?php $__env->startSection('content'); ?>
    <div class="col-md-9">
       <div class="card">
           <div class="card-header">
                <?php if(session('success')): ?>
                    <h5 class="text-success"><?php echo e(session('success')); ?></h5>
                <?php elseif(session('error')): ?>
                    <h5 class="text-danger"><?php echo e(session('errror')); ?></h5>
                <?php else: ?>
                    <h5><?php echo e(_('Add Product')); ?></h5>
                <?php endif; ?>
           </div>
            <div class="row">
                <form action="<?php echo e(route('product.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label class="form-lable">Category</label>
                    <select name="category" class="form-control" id="category">
                        <option value="">Select Category</option>
                        <?php $__currentLoopData = App\Models\Category::orderBy('name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value->id); ?>" <?php if($value->id==old('category')): ?> selected <?php endif; ?>><?php echo e($value->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-lable">Subcategory</label>
                    <select name="subcategory" class="form-control" id="subcategory">
                        <option value="">Select Subcategory</option>
                        <?php if(old('category')): ?>
                            <?php $__currentLoopData = App\Models\Subcategory::whereCategoryId(old('category'))->orderBy('name')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($value->id); ?>" <?php if($value->id==old('subcategory')): ?> selected <?php endif; ?>><?php echo e($value->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>

                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Name</label>
                    <input type="text" class="form-control" name="name" placeholder="Enter Subcategory Name" value="<?php echo e(old('name')); ?>">
                </div>
                <div class="form-group">
                    <label class="form-label">Price</label>
                    <input type="number" class="form-control" name="price" placeholder="Enter Price" value="<?php echo e(old('price')); ?>">
                </div>
                <div class="form-group">
                    <label class="form-label">Description</label>
                    <textarea name="description" class="form-control" rows="3"><?php echo e(old('decription')); ?></textarea>
                </div>
                <div class="form-group">
                    <button class="btn btn-success" type="submit">Save</button>
                </div>
                </form>
            </div>
       </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script type="text/javascript">
    $('#category').on('change', function() {
            get_subcategory_by_category();
        });
        function get_subcategory_by_category(){
          var category_id = $('#category').val();
          $.post('<?php echo e(route('getsubcategory')); ?>',{_token:'<?php echo e(csrf_token()); ?>', category_id:category_id}, function(data){
              $('#subcategory').html(null);
              $('#subcategory').append($('<option value="">Select Subcategory</option>', {

              }));
              for (var i = 0; i < data.length; i++) {
                  $('#subcategory').append($('<option>', {
                      value: data[i].id,
                      text: data[i].name
                  }));

              }
          });
        }
     </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\dynamic-drop-down\resources\views/product/create.blade.php ENDPATH**/ ?>