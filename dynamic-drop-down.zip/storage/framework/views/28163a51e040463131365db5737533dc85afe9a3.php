<?php $__env->startSection('content'); ?>
    <div class="col-md-9">
        <div class="row">
            <div class="col-md-12">
                <a href="<?php echo e(route('category.create')); ?>" class="btn btn-info">Add New Category</a>
            </div>
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <?php if(session('success')): ?>
                            <h5 class="text-success"><?php echo e(session('success')); ?></h5>
                        <?php elseif(session('error')): ?>
                            <h5 class="text-danger"><?php echo e(session('error')); ?></h5>
                        <?php else: ?>
                            <h5 class="text-dark"><?php echo e(__('Categories')); ?></h5>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>S.No.</th>
                                    <th>Name</th>
                                    <th>Update Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key+1); ?></td>
                                        <td><?php echo e($value->name); ?></td>
                                        <td><?php echo e($value->updated_at); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('category.edit',encrypt($value->id))); ?>">Edit</a><br>
                                            <a href="<?php echo e(route('category.delete',encrypt($value->id))); ?>">Delete</a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\xampp\htdocs\dynamic-drop-down\resources\views/category/index.blade.php ENDPATH**/ ?>