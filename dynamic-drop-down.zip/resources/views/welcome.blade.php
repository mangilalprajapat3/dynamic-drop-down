@extends('layouts.app')
@section('content')
    <div class="col-md-9">
        Body
    </div>
@endsection
